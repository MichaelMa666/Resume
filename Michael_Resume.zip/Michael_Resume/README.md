# Michael Ma Resume

***

It's a simple resume built by myself.

You can also view it in github.io: [demo](https://michaelma666.github.io/Resume/Michael_Resume/index.html)

If you want demo it in local, just download the project zip and decompres then double click the file index.html.(*╯3╰)